import MyModule as mm
# from MyModule import say_hello

if __name__ == "__main__":
    l = [1,2,3,5,'HENESSY']
    print(min(l))

    # mm.say_hello(name="Алексей Михайлович", age=37)
    # mm.say_hello(name="Алиса", age=16)
    # mm.say_hello(name="Иван", age=16)
    # mm.say_hello(name="Фёдор", age=16)
    # mm.say_bye()
