import datetime
date = datetime.date(2022,12,3)
print(date)