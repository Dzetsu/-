

if __name__ == '__main__':
    default_name = "Вася"
    names = []
