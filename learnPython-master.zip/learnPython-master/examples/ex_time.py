import time
for i in range(10):
    print(time.time_ns())
    time.sleep(0.5)